#' @param obs_index Name of column in \code{obs} to add as cell names; uses
#' \code{paste0("cell", obs_joinids())} by default
