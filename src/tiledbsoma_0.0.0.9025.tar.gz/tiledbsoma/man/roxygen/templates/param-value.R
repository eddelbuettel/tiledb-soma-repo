#' @param value Value to add for \code{<%= key %>}, or \code{NULL} to remove
#' the entry for \code{<%= key %>}
