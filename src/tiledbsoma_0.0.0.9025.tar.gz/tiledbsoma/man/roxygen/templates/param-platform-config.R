#' @param platform_config A \link[tiledbsoma:PlatformConfig]{platform configuration}
#' object
