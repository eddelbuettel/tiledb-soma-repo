#' @param var_column_names Names of columns in \code{var} to add as
#' feature-level meta data; by default, loads all columns
