#' @param var_index Name of column in \code{var} to add as feature names; uses
#' \code{paste0("feature", var_joinids())} by default
