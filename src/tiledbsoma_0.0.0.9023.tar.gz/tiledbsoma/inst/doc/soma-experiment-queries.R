## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(tiledbsoma)

## -----------------------------------------------------------------------------
experiment <- load_dataset("soma-exp-pbmc-small")
experiment

## -----------------------------------------------------------------------------
experiment$ms

## -----------------------------------------------------------------------------
query <- SOMAExperimentAxisQuery$new(
  experiment = experiment,
  measurement_name = "RNA"
)

## -----------------------------------------------------------------------------
query$n_obs

## -----------------------------------------------------------------------------
query$n_vars

## -----------------------------------------------------------------------------
query$obs()

## -----------------------------------------------------------------------------
obs_query <- SOMAAxisQuery$new(
  coords = list(soma_joinid = 0:39),
  value_filter = "nCount_RNA > 100"
)

## -----------------------------------------------------------------------------
query <- SOMAExperimentAxisQuery$new(
  experiment = experiment,
  measurement_name = "RNA",
  obs_query = obs_query
)

## -----------------------------------------------------------------------------
query$n_obs

## -----------------------------------------------------------------------------
query$obs(column_names = c("obs_id", "nCount_RNA"))$to_data_frame()

## -----------------------------------------------------------------------------
query$X(layer_name = "counts")

## ----eval=requireNamespace("SeuratObject", quietly = TRUE)--------------------
query$to_seurat(
  X_layers = c(counts = "counts", data = "data"),
  obs_index = "obs_id",
  var_index = "var_id"
)

