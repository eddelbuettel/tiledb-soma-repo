#' @param result_order Optional order of read results. This can be one of either
#' `"ROW_MAJOR, `"COL_MAJOR"`, or `"auto"` (default).
