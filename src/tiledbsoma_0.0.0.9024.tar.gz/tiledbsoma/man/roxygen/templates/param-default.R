#' @param default Default value to fetch if \code{<%= key %>} is not found;
#' defaults to \code{<%= default %>}
