#' @return This is a virtual class and cannot be directly instantiated
